// Due to https://github.com/esp8266/Arduino/issues/3205#issuecomment-299763849

#ifndef html_h
#define html_h

#include "Arduino.h"

String cssHTML ();
String gameHTML1 ();
String gameHTML2 ();
String gameHTML3 ();
String gameHTML4 ();
String authHTML1 ();
String authHTML2 ();
String authHTML3 ();
String authHTML4 ();

#endif
